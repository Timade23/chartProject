!(function (e) {
    var t = {};
    function a(n) {
        if (t[n]) return t[n].exports;
        var o = (t[n] = { i: n, l: !1, exports: {} });
        return e[n].call(o.exports, o, o.exports, a), (o.l = !0), o.exports;
    }
    (a.m = e),
        (a.c = t),
        (a.d = function (e, t, n) {
            a.o(e, t) || Object.defineProperty(e, t, { enumerable: !0, get: n });
        }),
        (a.r = function (e) {
            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e, "__esModule", { value: !0 });
        }),
        (a.t = function (e, t) {
            if ((1 & t && (e = a(e)), 8 & t)) return e;
            if (4 & t && "object" == typeof e && e && e.__esModule) return e;
            var n = Object.create(null);
            if ((a.r(n), Object.defineProperty(n, "default", { enumerable: !0, value: e }), 2 & t && "string" != typeof e))
                for (var o in e)
                    a.d(
                        n,
                        o,
                        function (t) {
                            return e[t];
                        }.bind(null, o)
                    );
            return n;
        }),
        (a.n = function (e) {
            var t =
                e && e.__esModule
                    ? function () {
                          return e.default;
                      }
                    : function () {
                          return e;
                      };
            return a.d(t, "a", t), t;
        }),
        (a.o = function (e, t) {
            return Object.prototype.hasOwnProperty.call(e, t);
        }),
        (a.p = "/"),
        a((a.s = 17));
})({
    17: function (e, t, a) {
        e.exports = a("I9Yi");
    },
    I9Yi: function (e, t) {
        (window.payfast_session_storage = window.sessionStorage),
            (window.payfast_do_onsite_payment = function (e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
                payfast_session_storage.setItem("payfast_payment", !0), window.addEventListener("beforeunload", a, !1), window.addEventListener("unload", n, { capture: !0 });
                var o = document.getElementsByTagName("head")[0],
                    s = document.getElementsByTagName("body")[0],
                    r = document.createElement("link"),
                    i = "sandbox.payfast.co.za";
                (r.id = "payfast_compact_engine_css"), (r.rel = "stylesheet"), (r.type = "text/css"), (r.href = "https://" + i + "/onsite/engine.css"), (r.media = "all"), o.appendChild(r);
                var p = document.createElement("div");
                (p.id = "payfast_div_container"), p.setAttribute("class", "payfast_compact_payment_modal"), s.appendChild(p);
                var l = document.createElement("iframe");
                l.setAttribute("id", "payfast_compact_engine_iframe"),
                    l.setAttribute("sandbox", "allow-scripts allow-same-origin allow-forms allow-pointer-lock allow-modals allow-popups"),
                    (l.allowTransparency = !0),
                    (l.src = "https://" + i + "/eng/process/payment/" + e.uuid),
                    (l.frameBorder = 0),
                    (l.width = "100%"),
                    (l.height = "100%"),
                    (l.style.backgroundColor = "transparent"),
                    p.appendChild(l),
                    (p.style.display = "block"),
                    (window.payfast_do_finish_callback =
                        "function" == typeof t
                            ? t
                            : function (t) {
                                  !0 === t ? void 0 !== e.return_url && "" !== e.return_url && window.location.replace(e.return_url) : void 0 !== e.cancel_url && "" !== e.cancel_url && window.location.replace(e.cancel_url);
                              }),
                    window.addEventListener("message", payfast_close_payment_popup, !1);
            }),
            (window.payfast_do_onsite_card_update = function (e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
                payfast_session_storage.setItem("payfast_payment", !0), window.addEventListener("beforeunload", a, !1), window.addEventListener("unload", n, { capture: !0 });
                var o = document.getElementsByTagName("head")[0],
                    s = document.getElementsByTagName("body")[0],
                    r = document.createElement("link"),
                    i = "sandbox.payfast.co.za";
                (r.id = "payfast_compact_engine_css"), (r.rel = "stylesheet"), (r.type = "text/css"), (r.href = "https://" + i + "/onsite/engine.css"), (r.media = "all"), o.appendChild(r);
                var p = document.createElement("div");
                (p.id = "payfast_div_container"), p.setAttribute("class", "payfast_compact_payment_modal"), s.appendChild(p);
                var l = document.createElement("iframe");
                l.setAttribute("id", "payfast_compact_engine_iframe"),
                    l.setAttribute("sandbox", "allow-scripts allow-same-origin allow-forms allow-pointer-lock allow-modals allow-popups"),
                    (l.allowTransparency = !0),
                    (l.src = "https://" + i + "/onsite/recurring/update/" + e),
                    (l.frameBorder = 0),
                    (l.width = "100%"),
                    (l.height = "100%"),
                    (l.style.backgroundColor = "transparent"),
                    p.appendChild(l),
                    (p.style.display = "block"),
                    (window.payfast_do_finish_callback =
                        "function" == typeof t
                            ? t
                            : function (e) {
                                  !0 === e && "string" == typeof t && "" !== t && window.location.replace(t);
                              }),
                    window.addEventListener("message", payfast_close_payment_popup, !1);
            }),
            (window.payfast_close_payment_popup = function (e) {
                "https://sandbox.payfast.co.za" === e.origin &&
                    "payfast_close_payment_popup" === e.data.requestFunction &&
                    (payfast_session_storage.getItem("payfast_payment") && payfast_session_storage.removeItem("payfast_payment"),
                    document.getElementById("payfast_div_container").remove(),
                    document.getElementById("payfast_compact_engine_css").remove(),
                    window.removeEventListener("message", payfast_close_payment_popup, !1),
                    window.removeEventListener("beforeunload", a, !1),
                    window.removeEventListener("unload", n, !1),
                    payfast_do_finish_callback(e.data.requestData));
            });
        var a = function (e) {
                if (payfast_session_storage.getItem("payfast_payment")) return e.preventDefault(), (e.returnValue = "Are you sure you want to exit the payment process?");
            },
            n = function e() {
                payfast_session_storage.removeItem("payfast_payment"), window.removeEventListener("message", payfast_close_payment_popup, !1), window.removeEventListener("beforeunload", a, !1), window.removeEventListener("unload", e, !1);
            };
    },
});
