export const environment = {
  production: true,
  payfastEndpoint: 'https://www.payfast.co.za/en/process',
  payfastOnsiteEndpoint: 'https://www.payfast.co.za/onsite/​process',

  squareEndpoint: 'https://connect.squareup.com/v2'
};
